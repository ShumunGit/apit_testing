
class errors_api:
    def __int__(self):
        pass


    # 400 Invalid ID supplied